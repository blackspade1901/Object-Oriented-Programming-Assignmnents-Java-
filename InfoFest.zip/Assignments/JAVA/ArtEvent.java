import java.time.LocalDate;

public class ArtEvent extends Event {

    public enum Medium { DIGITAL, TRADITIONAL }
    private Medium medium;

    public ArtEvent(String name,Mode   mode,LocalDate date,double entryFee,int teamLimit,Medium medium) {
        super(name, Type.ART, mode, date, entryFee, teamLimit);
        this.medium = medium;
    }

    @Override
    public String getRules() {
        return "Artwork must be created on-site; topic revealed at start.";
    }

    @Override
    public String getJudgingCriteria() {
        return "Technique 40%, Originality 40%, Theme Fit 20%.";
    }

    @Override
    public String getEventDetails() {
        return getName() + " — " + medium + " art";
    }

    public Medium getMedium() { return medium; }
}
