import java.time.LocalDate;

public class TechEvent extends Event {

    private String techStack;   
    private String tools;       

    public TechEvent(String name, Mode   mode,LocalDate date,double entryFee,int teamLimit,String techStack,String tools) {
        super(name, Type.TECH, mode, date, entryFee, teamLimit);
        this.techStack = techStack;
        this.tools = tools;
    }

    @Override
    public String getRules() {
        return "Code must be original; internet reference allowed; plagiarism = disqualify.";
    }

    @Override
    public String getJudgingCriteria() {
        return "Functionality 40%, Code Quality 30%, Innovation 30%.";
    }

    @Override
    public String getEventDetails() {
        return getName() + " — " + techStack + " (" + getEventMode() + ")";
    }

    public String getTechStack() { return techStack; }
    public String getTools() { return tools;     }
}
