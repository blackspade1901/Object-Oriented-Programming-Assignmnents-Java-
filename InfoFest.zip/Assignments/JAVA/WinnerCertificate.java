public class WinnerCertificate extends Certificate {

    private final String position;   
    public WinnerCertificate(String certificateId,String recipientName,String eventName,java.time.LocalDate issueDate,String position) {
        super(certificateId, recipientName, eventName, issueDate);
        this.position = position;
    }

    @Override
    public String getCertificateText() {
        return "Congratulations! " + getRecipientName()+ " secured " + position+ " in " + getEventName()+ " held on " + getIssueDate() + ".";
    }

    public String getPosition() { return position; }
}
