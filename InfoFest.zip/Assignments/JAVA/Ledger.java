import java.util.ArrayList;
import java.util.List;

public class Ledger {

    private final List<FinanceRecord> records = new ArrayList<>();

    public void add(FinanceRecord r) { records.add(r); }

    public double getBalance() {
        double total = 0.0;
        for (FinanceRecord r : records) {
            total += r.signedAmount();
        }
        return total;
    }

    public List<FinanceRecord> all() {
        return List.copyOf(records);
    }
}
