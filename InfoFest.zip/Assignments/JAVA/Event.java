import java.time.LocalDate;

public abstract class Event {

    private String  name;          
    private Type    eventType;     
    private Mode    eventMode;     
    private LocalDate date;       
    private double  entryFee;      
    private int     teamLimit;     

    public enum Type { TECH, NON_TECH, ART }
    public enum Mode { OFFLINE, ONLINE, HYBRID }

    public Event(String name,Type   eventType,Mode   eventMode,LocalDate date,double entryFee,int    teamLimit) {
        this.name = name;
        this.eventType = eventType;
        this.eventMode = eventMode;
        this.date = date;
        this.entryFee = entryFee;
        this.teamLimit = teamLimit;
    }

    public abstract String getRules();           
    public abstract String getJudgingCriteria();  
    public abstract String getEventDetails();     

    public String getName() { return name; }
    public Type getEventType() { return eventType; }
    public Mode getEventMode() { return eventMode; }
    public LocalDate getDate() { return date; }
    public double getEntryFee() { return entryFee; }
    public int getTeamLimit() { return teamLimit; }
}
