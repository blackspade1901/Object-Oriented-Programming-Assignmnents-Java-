public class LogisticsTeam extends Team {

    public LogisticsTeam(String teamName, String lead) { 
        super(teamName, lead); 
    }

    @Override 
    public String getPrimaryTask() { 
        return "Venue, transport, hospitality coordination"; 
    }

    @Override 
    public String getDailyTools()  { 
        return "Trello board, vendor contacts, maps"; 
    }

    @Override 
    public String getTeamDetails() {
        return getTeamName() + " books halls, buses, food, and handles guest arrivals.";
    }
}
