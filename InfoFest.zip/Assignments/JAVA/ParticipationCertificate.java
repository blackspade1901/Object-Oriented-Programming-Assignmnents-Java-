public class ParticipationCertificate extends Certificate {

    public ParticipationCertificate(String certificateId,String recipientName,String eventName,java.time.LocalDate issueDate) {
        super(certificateId, recipientName, eventName, issueDate);
    }

    @Override
    public String getCertificateText() {
        return "This is to certify that " + getRecipientName()+ " participated in " + getEventName()+ " on " + getIssueDate() + ".";
    }
}
