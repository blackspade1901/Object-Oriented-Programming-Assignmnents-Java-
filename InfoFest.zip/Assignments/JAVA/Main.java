import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

        InfoFest fest = new InfoFest("InfoFest-Lite 2025");

        Sponsor local = new LocalSponsor(
                "Ravi Desai", 8000,
                "GoaPrints", "Stage banners",
                "Panaji", true);
        Sponsor corp  = new CorporateSponsor(
                "Priya Shah", 75000,
                "CloudNova Ltd.", "Cash",
                "Software", true);

        fest.addSponsor(local);
        fest.addSponsor(corp);

        Event hackathon = new TechEvent(
                "CodeCraft Marathon", Event.Mode.OFFLINE,
                LocalDate.of(2025, 1, 24),
                200, 4,
                "Java / Spring", "IntelliJ");

        Event memeRush  = new NonTechEvent(
                "Meme-Forge Battle", Event.Mode.ONLINE,
                LocalDate.of(2025, 1, 24),
                0, 1, "Pop-Culture");

        Event artShow   = new ArtEvent(
                "Pixel-Palette Showdown", Event.Mode.HYBRID,
                LocalDate.of(2025, 1, 25),
                100, 1, ArtEvent.Medium.DIGITAL);

        fest.addEvent(hackathon);
        fest.addEvent(memeRush);
        fest.addEvent(artShow);

        Participant alice = new Participant("P-001", "Alice N.", "alice@mail.in", "Goa Univ");
        Participant bob   = new Participant("P-002", "Team ByteForce", "byte@uni.in", "Goa Univ");

        fest.addParticipant(alice);
        fest.addParticipant(bob);

        fest.register("P-001", "Meme-Forge Battle");
        fest.register("P-002", "CodeCraft Marathon");

        Team promo = new PromotionTeam("HypeSquad", "Riya Patel");
        promo.addMember("Sam");
        promo.addMember("Dee");
        fest.addTeam(promo);

        Team tech = new TechTeam("ByteCrew", "Akhil Rao");
        tech.addMember("Lila");
        fest.addTeam(tech);

        Certificate c1 = new ParticipationCertificate(
                "C-101", "Alice N.", "Meme-Forge Battle",
                LocalDate.of(2025, 1, 25));
        Certificate c2 = new WinnerCertificate(
                "C-102", "Team ByteForce", "CodeCraft Marathon",
                LocalDate.of(2025, 1, 26), "First Place");

        fest.addCertificate(c1);
        fest.addCertificate(c2);

        fest.addFinanceRecord(new FinanceRecord(
                "F-001", LocalDate.of(2025, 1, 10),
                "CloudNova Sponsorship", 75000, FinanceType.INCOME));
        fest.addFinanceRecord(new FinanceRecord(
                "F-002", LocalDate.of(2025, 1, 15),
                "Poster Printing", 4500, FinanceType.EXPENSE));

        fest.printSummary();
    }
}
