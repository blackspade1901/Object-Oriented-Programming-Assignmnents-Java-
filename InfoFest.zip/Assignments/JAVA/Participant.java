import java.util.ArrayList;
import java.util.List;

public class Participant {

    private final String  participantId;   
    private String  name;          
    private String  email;
    private String  college;
    private final List<Event> registeredEvents = new ArrayList<>();

    public Participant(String participantId,String name,String email,String college) {
        this.participantId = participantId;
        this.name = name;
        this.email = email;
        this.college = college;
    }

    public boolean register(Event event) {
        if (registeredEvents.contains(event)) return false;
        registeredEvents.add(event);
        return true;
    }

    public boolean cancel(Event event) {
        return registeredEvents.remove(event);
    }

    public List<Event> getRegisteredEvents() {
        return List.copyOf(registeredEvents);
    }

    public String getParticipantId() { return participantId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getCollege() { return college; }

    public void setName(String name) { this.name    = name; }
    public void setEmail(String email) { this.email   = email; }
    public void setCollege(String college) { this.college = college; }
}
