public class FinanceTeam extends Team {

    public FinanceTeam(String teamName, String lead) { 
        super(teamName, lead); 
    }

    @Override 
    public String getPrimaryTask() { 
        return "Budget tracking and payment clearance"; 
    }

    @Override 
    public String getDailyTools()  { 
        return "Excel, UPI dashboard, receipt scanner"; 
    }

    @Override 
    public String getTeamDetails() {
        return getTeamName() + " records income/expenses and settles vendor invoices.";
    }
}
