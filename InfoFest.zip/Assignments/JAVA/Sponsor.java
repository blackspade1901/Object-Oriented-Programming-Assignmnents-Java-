public abstract class Sponsor {

    protected String  name;
    protected double  amount;
    protected String  companyName;
    protected String  itemName;
    private SponsorshipStatus status;

    public enum SponsorshipStatus {
        PENDING, APPROVED, ACTIVE, REJECTED
    }

    public Sponsor(String name, double amount, String companyName, String itemName) { 
        this.name        = name;
        this.amount      = amount;
        this.companyName = companyName;
        this.itemName    = itemName;
        this.status      = SponsorshipStatus.PENDING;
    }

    public abstract double calculateSponsorshipValue();
    public abstract String  getSponsorshipTier();
    public abstract String  getSponsorDetails();

    public String  getName(){ 
        return name; 
    }
    public double  getAmount(){ 
        return amount; 
    }
    public String  getCompanyName(){ 
        return companyName; }
    public String  getItemName(){ 
        return itemName; 
    }
    public SponsorshipStatus getStatus(){ 
        return status; 
    }

    public void setName(String name){ 
        this.name = name; 
    }
    public void setAmount(double amount){ 
        this.amount = amount; 
    }
    public void setCompanyName(String companyName){ 
        this.companyName = companyName; 
    }
    public void setItemName(String itemName){ 
        this.itemName = itemName; 
    }

    public void evaluateStatus() {
        final double approval_threshold = 10000.0;
        this.status = amount >= approval_threshold
                      ? SponsorshipStatus.APPROVED
                      : SponsorshipStatus.REJECTED;
    }
}
