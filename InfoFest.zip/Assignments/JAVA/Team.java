import java.util.ArrayList;
import java.util.List;

public abstract class Team {

    private String teamName;         
    private String teamLead;       
    private final List<String> members = new ArrayList<>();

    public Team(String teamName, String teamLead) {
        this.teamName = teamName;
        this.teamLead = teamLead;
    }

    public abstract String getPrimaryTask();   
    public abstract String getDailyTools();    
    public abstract String getTeamDetails();   

    public void addMember(String member) { members.add(member); }
    public List<String> getMembers() { return List.copyOf(members); }

    public String getTeamName() { return teamName; }
    public String getTeamLead() { return teamLead; }
    public void   setTeamLead(String lead) { this.teamLead = lead; }
}
