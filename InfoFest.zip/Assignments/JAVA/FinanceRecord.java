import java.time.LocalDate;

public final class FinanceRecord {

    private final String id;       
    private final LocalDate date;       
    private final String description; 
    private final double amount;  
    private final FinanceType type;    

    public FinanceRecord(String id, LocalDate date,String description,double amount, FinanceType type) {
        this.id = id;
        this.date = date;
        this.description = description;
        this.amount = amount;
        this.type = type;
    }

    public String getId() { return id; }
    public LocalDate getDate() { return date; }
    public String getDescription() { return description; }
    public double getAmount() { return amount; }
    public FinanceType getType() { return type; }

    public double signedAmount() {
        return type == FinanceType.INCOME ? amount : -amount;
    }
}
