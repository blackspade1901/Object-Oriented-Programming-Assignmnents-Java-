
public class CorporateSponsor extends Sponsor {

    private String  industry;       
    private boolean nationalBrand;  

    public CorporateSponsor(String name,double amount,String companyName,String itemName,String industry,boolean nationalBrand) {
        super(name, amount, companyName, itemName);
        this.industry = industry;
        this.nationalBrand = nationalBrand;
    }

    @Override
    public double calculateSponsorshipValue() {
        return nationalBrand ? amount * 1.20 : amount;
    }

    @Override
    public String getSponsorshipTier() {
        return amount >= 25_000 ? "Corporate-Platinum"
             : amount >= 20_000 ? "Corporate-Gold"
             : amount >= 15_000 ? "Corporate-Silver"
             :                    "Corporate-Bronze";
    }

    @Override
    public String getSponsorDetails() {
        return companyName + " — " + industry + " sector";
    }

    public String  getIndustry()     { return industry; }
    public boolean isNationalBrand() { return nationalBrand; }
}
