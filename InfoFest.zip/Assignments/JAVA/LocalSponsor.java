public class LocalSponsor extends Sponsor{
     private String  locality;  
    private boolean recurring;  

    public LocalSponsor(String name, double amount,String companyName,String itemName,String locality,boolean recurring) {
        super(name, amount, companyName, itemName);
        this.locality  = locality;
        this.recurring = recurring;
    }

    @Override
    public double calculateSponsorshipValue() {
        return recurring ? amount * 1.10 : amount;
    }

    @Override
    public String getSponsorshipTier() {
        return amount >= 10_000 ? "Local-Premium"
             : amount >=  5_000 ? "Local-Standard"
             :                    "Local-Supporter";
    }

    @Override
    public String getSponsorDetails() {
        return companyName + " (“" + locality + "”)";
    }

    public String  getLocality() { return locality; }
    public boolean isRecurring() { return recurring; }
}
