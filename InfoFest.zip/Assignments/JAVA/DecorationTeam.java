public class DecorationTeam extends Team {

    public DecorationTeam(String teamName, String lead) { 
        super(teamName, lead); 
    }

    @Override 
    public String getPrimaryTask() { 
        return "Design & install venue décor"; 
    }

    @Override 
    public String getDailyTools()  { 
        return "Sketches, colours, Painting Brushes, Cloths, toolkits, Lights"; 
    }

    @Override 
    public String getTeamDetails() {
        return getTeamName() + " crafts the visual theme and ambience.";
    }
}
