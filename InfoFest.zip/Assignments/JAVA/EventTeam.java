public class EventTeam extends Team {

    public EventTeam(String teamName, String lead) {
        super(teamName, lead);
    }

    @Override 
    public String getPrimaryTask() { 
        return "Run stage-time, schedules, and on-site flow"; 
    }

    @Override 
    public String getDailyTools()  {
        return "G-Sheets schedule, radios, walkie-apps"; 
    }

    @Override 
    public String getTeamDetails() {
        return getTeamName() + " led by " + getTeamLead() + " handles all live-event execution.";
    }
}
