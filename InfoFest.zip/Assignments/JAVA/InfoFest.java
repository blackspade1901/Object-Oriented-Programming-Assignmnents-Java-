import java.util.ArrayList;
import java.util.List;

public class InfoFest {

    private final String festName;

    private final List<Sponsor> sponsors = new ArrayList<>();
    private final List<Event> events = new ArrayList<>();
    private final List<Participant> participants = new ArrayList<>();
    private final List<Team> teams = new ArrayList<>();
    private final List<Certificate> certificates = new ArrayList<>();

    private final Ledger ledger = new Ledger();

    public InfoFest(String festName) {
        this.festName = festName;
    }

    public void addSponsor(Sponsor s) { sponsors.add(s); }
    public void addEvent(Event e) { events.add(e);   }
    public void addParticipant(Participant p) { participants.add(p); }
    public void addTeam(Team t) { teams.add(t);    }
    public void addCertificate(Certificate c) { certificates.add(c); }
    public void addFinanceRecord(FinanceRecord r) { ledger.add(r); }

    public boolean register(String participantId, String eventName) {

        Participant p = findParticipant(participantId);
        Event e = findEvent(eventName);
        if (p == null || e == null) return false;
        return p.register(e);
    }

    public Participant findParticipant(String id) {
        for (Participant p : participants) {
            if (p.getParticipantId().equals(id)) return p;
        }
        return null;
    }
    public Event findEvent(String name) {
        for (Event e : events) {
            if (e.getName().equalsIgnoreCase(name)) return e;
        }
        return null;
    }

    public double getNetBalance() { return ledger.getBalance(); }

    public void printSummary() {

        System.out.println("=== " + festName + " SUMMARY ===");

        System.out.println("\nSponsors (" + sponsors.size() + "):");
        for (Sponsor s : sponsors) {
            System.out.println(" - " + s.getSponsorDetails());
        }

        System.out.println("\nEvents (" + events.size() + "):");
        for (Event e : events) {
            System.out.println(" - " + e.getEventDetails());
        }

        System.out.println("\nParticipants (" + participants.size() + "):");
        for (Participant p : participants) {
            System.out.println(" - " + p.getName()
                    + " -> " + p.getRegisteredEvents().size() + " events");
        }

        System.out.println("\nTeams (" + teams.size() + "):");
        for (Team t : teams) {
            System.out.println(" - " + t.getTeamName()
                    + " (" + t.getMembers().size() + " members)");
        }

        System.out.println("\nCertificates (" + certificates.size() + "):");
        for (Certificate c : certificates) {
            System.out.println(" - " + c.getCertificateText());
        }

        System.out.println("\nFinance balance: ₹" + getNetBalance());
        System.out.println("==================================");
    }
}
