public class PromotionTeam extends Team {

    public PromotionTeam(String teamName, String lead) { 
        super(teamName, lead); 
    }

    @Override 
    public String getPrimaryTask() { 
        return "Market the fest and grow audience reach"; 
    }

    @Override 
    public String getDailyTools()  { 
        return "Instagram, LinkedIn, Canva, Buffer"; 
    }

    @Override 
    public String getTeamDetails() {
        return getTeamName() + " curates social posts, posters, and press releases.";
    }
}
