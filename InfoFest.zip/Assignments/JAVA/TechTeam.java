public class TechTeam extends Team {

    public TechTeam(String teamName, String lead) { 
        super(teamName, lead); 
    }

    @Override 
    public String getPrimaryTask() { 
        return "Website, registration portal, live-stream"; 
    }

    @Override 
    public String getDailyTools()  { 
        return "VS Code, GitHub, OBS, cloud console"; 
    }

    @Override 
    public String getTeamDetails() {
        return getTeamName() + " maintains the site, Wi-Fi, and social-media integrations.";
    }
}
