import java.time.LocalDate;

public abstract class Certificate {

    private final String certificateId;  
    private final String recipientName;  
    private final String eventName;      
    private final LocalDate issueDate;       

    public Certificate(String certificateId,String recipientName,String eventName,LocalDate issueDate) {
        this.certificateId = certificateId;
        this.recipientName = recipientName;
        this.eventName = eventName;
        this.issueDate = issueDate;
    }

    public abstract String getCertificateText();

    public String    getCertificateId() { return certificateId; }
    public String    getRecipientName() { return recipientName; }
    public String    getEventName() { return eventName; }
    public LocalDate getIssueDate() { return issueDate; }
}
