
public enum FinanceType {
    INCOME , 
    EXPENSE
}
