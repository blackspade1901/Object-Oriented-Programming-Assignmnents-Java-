import java.time.LocalDate;

public class NonTechEvent extends Event {

    private String theme; 

    public NonTechEvent(String name,Mode   mode,LocalDate date, double entryFee,int teamLimit,String theme) {
        super(name, Type.NON_TECH, mode, date, entryFee, teamLimit);
        this.theme = theme;
    }

    @Override
    public String getRules() {
        return "Original content only; no profanity; time limit 2 hours.";
    }

    @Override
    public String getJudgingCriteria() {
        return "Creativity 50%, Audience Impact 30%, Theme Relevance 20%.";
    }

    @Override
    public String getEventDetails() {
        return getName() + " — theme: " + theme;
    }

    public String getTheme() { return theme; }
}
