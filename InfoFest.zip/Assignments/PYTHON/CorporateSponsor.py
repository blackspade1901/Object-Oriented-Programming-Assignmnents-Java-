from Sponsor import Sponsor

class CorporateSponsor(Sponsor):
    def __init__(self, name, amount, company_name, item_name, industry, national_brand):
        super().__init__(name, amount, company_name, item_name)
        self.industry = industry
        self.national_brand = national_brand

    def calculate_sponsorship_value(self):
        return self.amount * 1.20 if self.national_brand else self.amount

    def get_sponsorship_tier(self):
        if self.amount >= 25000:
            return "Corporate-Platinum"
        elif self.amount >= 20000:
            return "Corporate-Gold"
        elif self.amount >= 15000:
            return "Corporate-Silver"
        else:
            return "Corporate-Bronze"

    def get_sponsor_details(self):
        return f"{self.company_name} — {self.industry} sector"

    def get_industry(self):
        return self.industry

    def is_national_brand(self):
        return self.national_brand
