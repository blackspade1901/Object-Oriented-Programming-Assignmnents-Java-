from Sponsor import Sponsor

class LocalSponsor(Sponsor):
    def __init__(self, name, amount, company_name, item_name, locality, recurring):
        super().__init__(name, amount, company_name, item_name)
        self.locality = locality
        self.recurring = recurring

    def calculate_sponsorship_value(self):
        return self.amount * 1.10 if self.recurring else self.amount

    def get_sponsorship_tier(self):
        if self.amount >= 10000:
            return "Local-Premium"
        elif self.amount >= 5000:
            return "Local-Standard"
        else:
            return "Local-Supporter"

    def get_sponsor_details(self):
        return f'{self.company_name} (“{self.locality}”)'

    def get_locality(self):
        return self.locality

    def is_recurring(self):
        return self.recurring
