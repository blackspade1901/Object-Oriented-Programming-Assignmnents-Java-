from datetime import date

class Certificate:
    def __init__(self, certificate_id, recipient_name, event_name, issue_date):
        self.certificate_id = certificate_id
        self.recipient_name = recipient_name
        self.event_name = event_name
        self.issue_date = issue_date

    def get_certificate_text(self):
        raise NotImplementedError()

    def get_certificate_id(self):
        return self.certificate_id

    def get_recipient_name(self):
        return self.recipient_name

    def get_event_name(self):
        return self.event_name

    def get_issue_date(self):
        return self.issue_date
