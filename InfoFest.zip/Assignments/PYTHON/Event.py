from datetime import date
from enum import Enum

class Type(Enum):
    TECH = 'TECH'
    NON_TECH = 'NON_TECH'
    ART = 'ART'

class Mode(Enum):
    OFFLINE = 'OFFLINE'
    ONLINE = 'ONLINE'
    HYBRID = 'HYBRID'

class Event:
    def __init__(self, name, event_type, event_mode, date_, entry_fee, team_limit):
        self.name = name
        self.event_type = event_type
        self.event_mode = event_mode
        self.date = date_
        self.entry_fee = entry_fee
        self.team_limit = team_limit

    def get_rules(self):
        raise NotImplementedError()

    def get_judging_criteria(self):
        raise NotImplementedError()

    def get_event_details(self):
        raise NotImplementedError()

    def get_name(self):
        return self.name

    def get_event_type(self):
        return self.event_type

    def get_event_mode(self):
        return self.event_mode

    def get_date(self):
        return self.date

    def get_entry_fee(self):
        return self.entry_fee

    def get_team_limit(self):
        return self.team_limit
