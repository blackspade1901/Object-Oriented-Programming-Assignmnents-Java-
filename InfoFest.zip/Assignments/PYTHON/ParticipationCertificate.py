from Certificate import Certificate

class ParticipationCertificate(Certificate):
    def __init__(self, certificate_id, recipient_name, event_name, issue_date):
        super().__init__(certificate_id, recipient_name, event_name, issue_date)

    def get_certificate_text(self):
        return f"This is to certify that {self.get_recipient_name()} participated in {self.get_event_name()} on {self.get_issue_date()}."
