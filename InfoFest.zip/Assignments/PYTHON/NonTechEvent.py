from Event import Event, Type, Mode
from datetime import date

class NonTechEvent(Event):
    def __init__(self, name, mode, date_, entry_fee, team_limit, theme):
        super().__init__(name, Type.NON_TECH, mode, date_, entry_fee, team_limit)
        self.theme = theme

    def get_rules(self):
        return "Original content only; no profanity; time limit 2 hours."

    def get_judging_criteria(self):
        return "Creativity 50%, Audience Impact 30%, Theme Relevance 20%."

    def get_event_details(self):
        return f"{self.get_name()} — theme: {self.theme}"

    def get_theme(self):
        return self.theme
