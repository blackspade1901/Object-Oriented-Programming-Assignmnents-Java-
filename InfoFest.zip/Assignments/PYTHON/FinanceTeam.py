from Team import Team

class FinanceTeam(Team):
    def __init__(self, team_name, lead):
        super().__init__(team_name, lead)

    def get_primary_task(self):
        return "Budget tracking and payment clearance"

    def get_daily_tools(self):
        return "Excel, UPI dashboard, receipt scanner"

    def get_team_details(self):
        return f"{self.get_team_name()} records income/expenses and settles vendor invoices."
