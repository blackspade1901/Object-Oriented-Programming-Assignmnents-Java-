from Certificate import Certificate

class WinnerCertificate(Certificate):
    def __init__(self, certificate_id, recipient_name, event_name, issue_date, position):
        super().__init__(certificate_id, recipient_name, event_name, issue_date)
        self.position = position

    def get_certificate_text(self):
        return f"Congratulations! {self.get_recipient_name()} secured {self.position} in {self.get_event_name()} held on {self.get_issue_date()}."

    def get_position(self):
        return self.position
