from datetime import date
from Event import Event, Type, Mode
from enum import Enum

class Medium(Enum):
    DIGITAL = 'DIGITAL'
    TRADITIONAL = 'TRADITIONAL'

class ArtEvent(Event):
    def __init__(self, name, mode, date_, entry_fee, team_limit, medium):
        super().__init__(name, Type.ART, mode, date_, entry_fee, team_limit)
        self.medium = medium

    def get_rules(self):
        return "Artwork must be created on-site; topic revealed at start."

    def get_judging_criteria(self):
        return "Technique 40%, Originality 40%, Theme Fit 20%."

    def get_event_details(self):
        return f"{self.get_name()} — {self.medium.value} art"

    def get_medium(self):
        return self.medium
