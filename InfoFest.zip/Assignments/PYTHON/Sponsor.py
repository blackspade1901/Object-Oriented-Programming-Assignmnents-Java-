from enum import Enum

class SponsorshipStatus(Enum):
    PENDING = 'PENDING'
    APPROVED = 'APPROVED'
    ACTIVE = 'ACTIVE'
    REJECTED = 'REJECTED'

class Sponsor:
    def __init__(self, name, amount, company_name, item_name):
        self.name = name
        self.amount = amount
        self.company_name = company_name
        self.item_name = item_name
        self.status = SponsorshipStatus.PENDING

    def calculate_sponsorship_value(self):
        raise NotImplementedError()

    def get_sponsorship_tier(self):
        raise NotImplementedError()

    def get_sponsor_details(self):
        raise NotImplementedError()

    def get_name(self):
        return self.name

    def get_amount(self):
        return self.amount

    def get_company_name(self):
        return self.company_name

    def get_item_name(self):
        return self.item_name

    def get_status(self):
        return self.status

    def set_name(self, name):
        self.name = name

    def set_amount(self, amount):
        self.amount = amount

    def set_company_name(self, company_name):
        self.company_name = company_name

    def set_item_name(self, item_name):
        self.item_name = item_name

    def evaluate_status(self):
        approval_threshold = 10000.0
        self.status = SponsorshipStatus.APPROVED if self.amount >= approval_threshold else SponsorshipStatus.REJECTED
