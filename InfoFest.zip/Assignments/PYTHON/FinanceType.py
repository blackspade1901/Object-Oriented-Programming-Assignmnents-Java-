from enum import Enum

class FinanceType(Enum):
    INCOME = 'INCOME'
    EXPENSE = 'EXPENSE'
