class Team:
    def __init__(self, team_name, team_lead):
        self.team_name = team_name
        self.team_lead = team_lead
        self.members = []

    def get_primary_task(self):
        raise NotImplementedError()

    def get_daily_tools(self):
        raise NotImplementedError()

    def get_team_details(self):
        raise NotImplementedError()

    def add_member(self, member):
        self.members.append(member)

    def get_members(self):
        return self.members.copy()

    def get_team_name(self):
        return self.team_name

    def get_team_lead(self):
        return self.team_lead

    def set_team_lead(self, lead):
        self.team_lead = lead
