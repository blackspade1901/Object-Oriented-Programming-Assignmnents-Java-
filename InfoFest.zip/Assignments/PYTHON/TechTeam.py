from Team import Team

class TechTeam(Team):
    def __init__(self, team_name, lead):
        super().__init__(team_name, lead)

    def get_primary_task(self):
        return "Website, registration portal, live-stream"

    def get_daily_tools(self):
        return "VS Code, GitHub, OBS, cloud console"

    def get_team_details(self):
        return f"{self.get_team_name()} maintains the site, Wi-Fi, and social-media integrations."
