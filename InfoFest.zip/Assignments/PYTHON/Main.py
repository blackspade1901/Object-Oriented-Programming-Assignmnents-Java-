from datetime import date

from InfoFest import InfoFest
from LocalSponsor import LocalSponsor
from CorporateSponsor import CorporateSponsor
from TechEvent import TechEvent
from NonTechEvent import NonTechEvent
from ArtEvent import ArtEvent, Medium
from Participant import Participant
from PromotionTeam import PromotionTeam
from TechTeam import TechTeam
from ParticipationCertificate import ParticipationCertificate
from WinnerCertificate import WinnerCertificate
from FinanceRecord import FinanceRecord
from FinanceType import FinanceType
from Event import Mode

def main():
    fest = InfoFest("InfoFest-Lite 2025")

    local = LocalSponsor(
        "Ravi Desai", 8000,
        "GoaPrints", "Stage banners",
        "Panaji", True)
    corp = CorporateSponsor(
        "Priya Shah", 75000,
        "CloudNova Ltd.", "Cash",
        "Software", True)

    fest.add_sponsor(local)
    fest.add_sponsor(corp)

    hackathon = TechEvent(
        "CodeCraft Marathon", Mode.OFFLINE,
        date(2025, 1, 24),
        200, 4,
        "Java / Spring", "IntelliJ")

    memeRush = NonTechEvent(
        "Meme-Forge Battle", Mode.ONLINE,
        date(2025, 1, 24),
        0, 1, "Pop-Culture")

    artShow = ArtEvent(
        "Pixel-Palette Showdown", Mode.HYBRID,
        date(2025, 1, 25),
        100, 1, Medium.DIGITAL)

    fest.add_event(hackathon)
    fest.add_event(memeRush)
    fest.add_event(artShow)

    alice = Participant("P-001", "Alice N.", "alice@mail.in", "Goa Univ")
    bob = Participant("P-002", "Team ByteForce", "byte@uni.in", "Goa Univ")

    fest.add_participant(alice)
    fest.add_participant(bob)

    fest.register("P-001", "Meme-Forge Battle")
    fest.register("P-002", "CodeCraft Marathon")

    promo = PromotionTeam("HypeSquad", "Riya Patel")
    promo.add_member("Sam")
    promo.add_member("Dee")
    fest.add_team(promo)

    tech = TechTeam("ByteCrew", "Akhil Rao")
    tech.add_member("Lila")
    fest.add_team(tech)

    c1 = ParticipationCertificate(
        "C-101", "Alice N.", "Meme-Forge Battle",
        date(2025, 1, 25))
    c2 = WinnerCertificate(
        "C-102", "Team ByteForce", "CodeCraft Marathon",
        date(2025, 1, 26), "First Place")

    fest.add_certificate(c1)
    fest.add_certificate(c2)

    fest.add_finance_record(FinanceRecord(
        "F-001", date(2025, 1, 10),
        "CloudNova Sponsorship", 75000, FinanceType.INCOME))
    fest.add_finance_record(FinanceRecord(
        "F-002", date(2025, 1, 15),
        "Poster Printing", 4500, FinanceType.EXPENSE))

    fest.print_summary()

if __name__ == "__main__":
    main()
