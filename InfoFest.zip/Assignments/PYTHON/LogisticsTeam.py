from Team import Team

class LogisticsTeam(Team):
    def __init__(self, team_name, lead):
        super().__init__(team_name, lead)

    def get_primary_task(self):
        return "Venue, transport, hospitality coordination"

    def get_daily_tools(self):
        return "Trello board, vendor contacts, maps"

    def get_team_details(self):
        return f"{self.get_team_name()} books halls, buses, food, and handles guest arrivals."
