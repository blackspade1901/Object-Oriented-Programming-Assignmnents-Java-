from Team import Team

class EventTeam(Team):
    def __init__(self, team_name, lead):
        super().__init__(team_name, lead)

    def get_primary_task(self):
        return "Run stage-time, schedules, and on-site flow"

    def get_daily_tools(self):
        return "G-Sheets schedule, radios, walkie-apps"

    def get_team_details(self):
        return f"{self.get_team_name()} led by {self.get_team_lead()} handles all live-event execution."
