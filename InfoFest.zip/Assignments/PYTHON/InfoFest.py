from Ledger import Ledger

class InfoFest:
    def __init__(self, fest_name):
        self.fest_name = fest_name
        self.sponsors = []
        self.events = []
        self.participants = []
        self.teams = []
        self.certificates = []
        self.ledger = Ledger()

    def add_sponsor(self, s):
        self.sponsors.append(s)

    def add_event(self, e):
        self.events.append(e)

    def add_participant(self, p):
        self.participants.append(p)

    def add_team(self, t):
        self.teams.append(t)

    def add_certificate(self, c):
        self.certificates.append(c)

    def add_finance_record(self, r):
        self.ledger.add(r)

    def register(self, participant_id, event_name):
        p = self.find_participant(participant_id)
        e = self.find_event(event_name)
        if p is None or e is None:
            return False
        return p.register(e)

    def find_participant(self, id_):
        for p in self.participants:
            if p.get_participant_id() == id_:
                return p
        return None

    def find_event(self, name):
        for e in self.events:
            if e.get_name().lower() == name.lower():
                return e
        return None

    def get_net_balance(self):
        return self.ledger.get_balance()

    def print_summary(self):
        print(f"=== {self.fest_name} SUMMARY ===")
        print(f"\nSponsors ({len(self.sponsors)}):")
        for s in self.sponsors:
            print(f" - {s.get_sponsor_details()}")
        print(f"\nEvents ({len(self.events)}):")
        for e in self.events:
            print(f" - {e.get_event_details()}")
        print(f"\nParticipants ({len(self.participants)}):")
        for p in self.participants:
            print(f" - {p.get_name()} -> {len(p.get_registered_events())} events")
        print(f"\nTeams ({len(self.teams)}):")
        for t in self.teams:
            print(f" - {t.get_team_name()} ({len(t.get_members())} members)")
        print(f"\nCertificates ({len(self.certificates)}):")
        for c in self.certificates:
            print(f" - {c.get_certificate_text()}")
        print(f"\nFinance balance: ₹{self.get_net_balance()}")
        print("==================================")
