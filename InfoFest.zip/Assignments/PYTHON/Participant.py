class Participant:
    def __init__(self, participant_id, name, email, college):
        self.participant_id = participant_id
        self.name = name
        self.email = email
        self.college = college
        self.registered_events = []

    def register(self, event):
        if event in self.registered_events:
            return False
        self.registered_events.append(event)
        return True

    def cancel(self, event):
        if event in self.registered_events:
            self.registered_events.remove(event)
            return True
        return False

    def get_registered_events(self):
        return self.registered_events.copy()

    def get_participant_id(self):
        return self.participant_id

    def get_name(self):
        return self.name

    def get_email(self):
        return self.email

    def get_college(self):
        return self.college

    def set_name(self, name):
        self.name = name

    def set_email(self, email):
        self.email = email

    def set_college(self, college):
        self.college = college
