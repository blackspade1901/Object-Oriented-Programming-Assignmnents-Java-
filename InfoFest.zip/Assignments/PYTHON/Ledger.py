from FinanceRecord import FinanceRecord

class Ledger:
    def __init__(self):
        self.records = []

    def add(self, r):
        self.records.append(r)

    def get_balance(self):
        total = 0.0
        for r in self.records:
            total += r.signed_amount()
        return total

    def all(self):
        return self.records.copy()
