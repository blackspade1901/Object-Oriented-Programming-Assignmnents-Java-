from Event import Event, Type, Mode
from datetime import date

class TechEvent(Event):
    def __init__(self, name, mode, date_, entry_fee, team_limit, tech_stack, tools):
        super().__init__(name, Type.TECH, mode, date_, entry_fee, team_limit)
        self.tech_stack = tech_stack
        self.tools = tools

    def get_rules(self):
        return "Code must be original; internet reference allowed; plagiarism = disqualify."

    def get_judging_criteria(self):
        return "Functionality 40%, Code Quality 30%, Innovation 30%."

    def get_event_details(self):
        return f"{self.get_name()} — {self.tech_stack} ({self.get_event_mode().value})"

    def get_tech_stack(self):
        return self.tech_stack

    def get_tools(self):
        return self.tools
