from Team import Team

class PromotionTeam(Team):
    def __init__(self, team_name, lead):
        super().__init__(team_name, lead)

    def get_primary_task(self):
        return "Market the fest and grow audience reach"

    def get_daily_tools(self):
        return "Instagram, LinkedIn, Canva, Buffer"

    def get_team_details(self):
        return f"{self.get_team_name()} curates social posts, posters, and press releases."
