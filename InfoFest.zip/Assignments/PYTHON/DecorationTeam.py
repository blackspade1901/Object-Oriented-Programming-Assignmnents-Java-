from Team import Team

class DecorationTeam(Team):
    def __init__(self, team_name, lead):
        super().__init__(team_name, lead)

    def get_primary_task(self):
        return "Design & install venue décor"

    def get_daily_tools(self):
        return "Sketches, colours, Painting Brushes, Cloths, toolkits, Lights"

    def get_team_details(self):
        return f"{self.get_team_name()} crafts the visual theme and ambience."
