from datetime import date
from FinanceType import FinanceType

class FinanceRecord:
    def __init__(self, id_, date_, description, amount, type_):
        self.id = id_
        self.date = date_
        self.description = description
        self.amount = amount
        self.type = type_

    def get_id(self):
        return self.id

    def get_date(self):
        return self.date

    def get_description(self):
        return self.description

    def get_amount(self):
        return self.amount

    def get_type(self):
        return self.type

    def signed_amount(self):
        return self.amount if self.type == FinanceType.INCOME else -self.amount
