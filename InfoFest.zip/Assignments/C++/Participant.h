#pragma once
#include <string>
#include <vector>
#include "Event.h"

class Participant {
public:
    Participant(const std::string& participantId, const std::string& name, const std::string& email, const std::string& college);
    bool registerEvent(Event* event);
    bool cancelEvent(Event* event);
    std::vector<Event*> getRegisteredEvents() const;
    std::string getParticipantId() const;
    std::string getName() const;
    std::string getEmail() const;
    std::string getCollege() const;
    void setName(const std::string& name);
    void setEmail(const std::string& email);
    void setCollege(const std::string& college);
private:
    std::string participantId;
    std::string name;
    std::string email;
    std::string college;
    std::vector<Event*> registeredEvents;
};
