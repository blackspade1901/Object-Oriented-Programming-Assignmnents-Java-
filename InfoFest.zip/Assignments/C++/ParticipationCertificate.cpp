#include "ParticipationCertificate.h"

ParticipationCertificate::ParticipationCertificate(const std::string& certificateId, const std::string& recipientName, const std::string& eventName, std::tm issueDate)
    : Certificate(certificateId, recipientName, eventName, issueDate) {}

std::string ParticipationCertificate::getCertificateText() const {
    return "This is to certify that " + getRecipientName() + " participated in " + getEventName() + " on " + std::to_string(issueDate.tm_mday) + "/" + std::to_string(issueDate.tm_mon+1) + "/" + std::to_string(issueDate.tm_year+1900) + ".";
}
