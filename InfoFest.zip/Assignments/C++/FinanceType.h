#pragma once

enum class FinanceType {
    INCOME,
    EXPENSE
};
