#include "CorporateSponsor.h"

CorporateSponsor::CorporateSponsor(const std::string& name, double amount, const std::string& companyName, const std::string& itemName, const std::string& industry, bool nationalBrand)
    : Sponsor(name, amount, companyName, itemName), industry(industry), nationalBrand(nationalBrand) {}

double CorporateSponsor::calculateSponsorshipValue() const {
    return nationalBrand ? amount * 1.20 : amount;
}

std::string CorporateSponsor::getSponsorshipTier() const {
    if (amount >= 25000) return "Corporate-Platinum";
    else if (amount >= 20000) return "Corporate-Gold";
    else if (amount >= 15000) return "Corporate-Silver";
    else return "Corporate-Bronze";
}

std::string CorporateSponsor::getSponsorDetails() const {
    return companyName + " — " + industry + " sector";
}

std::string CorporateSponsor::getIndustry() const {
    return industry;
}

bool CorporateSponsor::isNationalBrand() const {
    return nationalBrand;
}
