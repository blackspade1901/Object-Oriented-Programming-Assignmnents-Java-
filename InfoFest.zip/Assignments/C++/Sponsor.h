#pragma once
#include <string>

class Sponsor {
public:
    enum class SponsorshipStatus {
        PENDING, APPROVED, ACTIVE, REJECTED
    };
    Sponsor(const std::string& name, double amount, const std::string& companyName, const std::string& itemName);
    virtual ~Sponsor() = default;
    virtual double calculateSponsorshipValue() const = 0;
    virtual std::string getSponsorshipTier() const = 0;
    virtual std::string getSponsorDetails() const = 0;
    std::string getName() const;
    double getAmount() const;
    std::string getCompanyName() const;
    std::string getItemName() const;
    SponsorshipStatus getStatus() const;
    void setName(const std::string& name);
    void setAmount(double amount);
    void setCompanyName(const std::string& companyName);
    void setItemName(const std::string& itemName);
    void evaluateStatus();
protected:
    std::string name;
    double amount;
    std::string companyName;
    std::string itemName;
    SponsorshipStatus status;
};
