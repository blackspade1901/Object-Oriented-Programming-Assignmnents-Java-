#include "Team.h"

Team::Team(const std::string& teamName, const std::string& teamLead)
    : teamName(teamName), teamLead(teamLead) {}

void Team::addMember(const std::string& member) {
    members.push_back(member);
}

std::vector<std::string> Team::getMembers() const {
    return members;
}

std::string Team::getTeamName() const {
    return teamName;
}

std::string Team::getTeamLead() const {
    return teamLead;
}

void Team::setTeamLead(const std::string& lead) {
    teamLead = lead;
}
