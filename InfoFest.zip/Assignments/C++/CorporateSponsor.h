#pragma once
#include "Sponsor.h"
#include <string>

class CorporateSponsor : public Sponsor {
public:
    CorporateSponsor(const std::string& name, double amount, const std::string& companyName, const std::string& itemName, const std::string& industry, bool nationalBrand);
    double calculateSponsorshipValue() const override;
    std::string getSponsorshipTier() const override;
    std::string getSponsorDetails() const override;
    std::string getIndustry() const;
    bool isNationalBrand() const;
private:
    std::string industry;
    bool nationalBrand;
};
