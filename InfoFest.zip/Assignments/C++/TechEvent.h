#pragma once
#include "Event.h"
#include <string>

class TechEvent : public Event {
public:
    TechEvent(const std::string& name, Mode mode, std::tm date, double entryFee, int teamLimit, const std::string& techStack, const std::string& tools);
    std::string getRules() const override;
    std::string getJudgingCriteria() const override;
    std::string getEventDetails() const override;
    std::string getTechStack() const;
    std::string getTools() const;
private:
    std::string techStack;
    std::string tools;
};
