#include "InfoFest.h"
#include <iostream>

InfoFest::InfoFest(const std::string& festName)
    : festName(festName) {}

void InfoFest::addSponsor(Sponsor* s) { sponsors.push_back(s); }
void InfoFest::addEvent(Event* e) { events.push_back(e); }
void InfoFest::addParticipant(Participant* p) { participants.push_back(p); }
void InfoFest::addTeam(Team* t) { teams.push_back(t); }
void InfoFest::addCertificate(Certificate* c) { certificates.push_back(c); }
void InfoFest::addFinanceRecord(const FinanceRecord& r) { ledger.add(r); }

bool InfoFest::registerParticipant(const std::string& participantId, const std::string& eventName) {
    Participant* p = findParticipant(participantId);
    Event* e = findEvent(eventName);
    if (!p || !e) return false;
    return p->registerEvent(e);
}

Participant* InfoFest::findParticipant(const std::string& id) {
    for (auto* p : participants) {
        if (p->getParticipantId() == id) return p;
    }
    return nullptr;
}

Event* InfoFest::findEvent(const std::string& name) {
    for (auto* e : events) {
        if (e->getName() == name) return e;
    }
    return nullptr;
}

double InfoFest::getNetBalance() const {
    return ledger.getBalance();
}

void InfoFest::printSummary() const {
    std::cout << "=== " << festName << " SUMMARY ===\n";
    std::cout << "\nSponsors (" << sponsors.size() << "):\n";
    for (auto* s : sponsors) {
        std::cout << " - " << s->getSponsorDetails() << "\n";
    }
    std::cout << "\nEvents (" << events.size() << "):\n";
    for (auto* e : events) {
        std::cout << " - " << e->getEventDetails() << "\n";
    }
    std::cout << "\nParticipants (" << participants.size() << "):\n";
    for (auto* p : participants) {
        std::cout << " - " << p->getName() << " -> " << p->getRegisteredEvents().size() << " events\n";
    }
    std::cout << "\nTeams (" << teams.size() << "):\n";
    for (auto* t : teams) {
        std::cout << " - " << t->getTeamName() << " (" << t->getMembers().size() << " members)\n";
    }
    std::cout << "\nCertificates (" << certificates.size() << "):\n";
    for (auto* c : certificates) {
        std::cout << " - " << c->getCertificateText() << "\n";
    }
    std::cout << "\nFinance balance: ₹" << getNetBalance() << "\n";
    std::cout << "==================================\n";
}
