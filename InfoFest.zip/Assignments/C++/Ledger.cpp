#include "Ledger.h"

void Ledger::add(const FinanceRecord& r) {
    records.push_back(r);
}

double Ledger::getBalance() const {
    double total = 0.0;
    for (const auto& r : records) {
        total += r.signedAmount();
    }
    return total;
}

std::vector<FinanceRecord> Ledger::all() const {
    return records;
}
