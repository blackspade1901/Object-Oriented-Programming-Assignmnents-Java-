#include "PromotionTeam.h"

PromotionTeam::PromotionTeam(const std::string& teamName, const std::string& lead)
    : Team(teamName, lead) {}

std::string PromotionTeam::getPrimaryTask() const {
    return "Market the fest and grow audience reach";
}

std::string PromotionTeam::getDailyTools() const {
    return "Instagram, LinkedIn, Canva, Buffer";
}

std::string PromotionTeam::getTeamDetails() const {
    return getTeamName() + " curates social posts, posters, and press releases.";
}
