#pragma once
#include <string>
#include <ctime>
#include "FinanceType.h"

class FinanceRecord {
public:
    FinanceRecord(const std::string& id, std::tm date, const std::string& description, double amount, FinanceType type);
    std::string getId() const;
    std::tm getDate() const;
    std::string getDescription() const;
    double getAmount() const;
    FinanceType getType() const;
    double signedAmount() const;
private:
    std::string id;
    std::tm date;
    std::string description;
    double amount;
    FinanceType type;
};
