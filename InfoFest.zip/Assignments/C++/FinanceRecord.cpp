#include "FinanceRecord.h"

FinanceRecord::FinanceRecord(const std::string& id, std::tm date, const std::string& description, double amount, FinanceType type)
    : id(id), date(date), description(description), amount(amount), type(type) {}

std::string FinanceRecord::getId() const { return id; }
std::tm FinanceRecord::getDate() const { return date; }
std::string FinanceRecord::getDescription() const { return description; }
double FinanceRecord::getAmount() const { return amount; }
FinanceType FinanceRecord::getType() const { return type; }
double FinanceRecord::signedAmount() const { return type == FinanceType::INCOME ? amount : -amount; }
