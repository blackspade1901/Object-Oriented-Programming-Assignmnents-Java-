#include "LocalSponsor.h"

LocalSponsor::LocalSponsor(const std::string& name, double amount, const std::string& companyName, const std::string& itemName, const std::string& locality, bool recurring)
    : Sponsor(name, amount, companyName, itemName), locality(locality), recurring(recurring) {}

double LocalSponsor::calculateSponsorshipValue() const {
    return recurring ? amount * 1.10 : amount;
}

std::string LocalSponsor::getSponsorshipTier() const {
    if (amount >= 10000) return "Local-Premium";
    else if (amount >= 5000) return "Local-Standard";
    else return "Local-Supporter";
}

std::string LocalSponsor::getSponsorDetails() const {
    return companyName + " (" + locality + ")";
}

std::string LocalSponsor::getLocality() const {
    return locality;
}

bool LocalSponsor::isRecurring() const {
    return recurring;
}
