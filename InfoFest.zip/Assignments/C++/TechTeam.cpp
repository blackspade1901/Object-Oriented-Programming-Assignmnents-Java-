#include "TechTeam.h"

TechTeam::TechTeam(const std::string& teamName, const std::string& lead)
    : Team(teamName, lead) {}

std::string TechTeam::getPrimaryTask() const {
    return "Website, registration portal, live-stream";
}

std::string TechTeam::getDailyTools() const {
    return "VS Code, GitHub, OBS, cloud console";
}

std::string TechTeam::getTeamDetails() const {
    return getTeamName() + " maintains the site, Wi-Fi, and social-media integrations.";
}
