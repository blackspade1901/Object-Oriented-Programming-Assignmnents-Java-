#pragma once
#include <string>
#include <vector>

class Team {
public:
    Team(const std::string& teamName, const std::string& teamLead);
    virtual ~Team() = default;
    virtual std::string getPrimaryTask() const = 0;
    virtual std::string getDailyTools() const = 0;
    virtual std::string getTeamDetails() const = 0;
    void addMember(const std::string& member);
    std::vector<std::string> getMembers() const;
    std::string getTeamName() const;
    std::string getTeamLead() const;
    void setTeamLead(const std::string& lead);
protected:
    std::string teamName;
    std::string teamLead;
    std::vector<std::string> members;
};
