#include "NonTechEvent.h"

NonTechEvent::NonTechEvent(const std::string& name, Mode mode, std::tm date, double entryFee, int teamLimit, const std::string& theme)
    : Event(name, Type::NON_TECH, mode, date, entryFee, teamLimit), theme(theme) {}

std::string NonTechEvent::getRules() const {
    return "Original content only; no profanity; time limit 2 hours.";
}

std::string NonTechEvent::getJudgingCriteria() const {
    return "Creativity 50%, Audience Impact 30%, Theme Relevance 20%.";
}

std::string NonTechEvent::getEventDetails() const {
    return getName() + " — theme: " + theme;
}

std::string NonTechEvent::getTheme() const {
    return theme;
}
