#include "FinanceTeam.h"

FinanceTeam::FinanceTeam(const std::string& teamName, const std::string& lead)
    : Team(teamName, lead) {}

std::string FinanceTeam::getPrimaryTask() const {
    return "Budget tracking and payment clearance";
}

std::string FinanceTeam::getDailyTools() const {
    return "Excel, UPI dashboard, receipt scanner";
}

std::string FinanceTeam::getTeamDetails() const {
    return getTeamName() + " records income/expenses and settles vendor invoices.";
}
