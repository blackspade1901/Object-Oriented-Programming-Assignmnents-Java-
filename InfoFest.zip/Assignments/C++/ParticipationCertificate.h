#pragma once
#include "Certificate.h"
#include <string>

class ParticipationCertificate : public Certificate {
public:
    ParticipationCertificate(const std::string& certificateId, const std::string& recipientName, const std::string& eventName, std::tm issueDate);
    std::string getCertificateText() const override;
};
