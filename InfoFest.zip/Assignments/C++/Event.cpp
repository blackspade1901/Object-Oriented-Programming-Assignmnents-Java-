#include "Event.h"

Event::Event(const std::string& name, Type eventType, Mode eventMode, std::tm date, double entryFee, int teamLimit)
    : name(name), eventType(eventType), eventMode(eventMode), date(date), entryFee(entryFee), teamLimit(teamLimit) {}

std::string Event::getName() const { return name; }
Event::Type Event::getEventType() const { return eventType; }
Event::Mode Event::getEventMode() const { return eventMode; }
std::tm Event::getDate() const { return date; }
double Event::getEntryFee() const { return entryFee; }
int Event::getTeamLimit() const { return teamLimit; }
