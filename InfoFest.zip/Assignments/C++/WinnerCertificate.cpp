#include "WinnerCertificate.h"

WinnerCertificate::WinnerCertificate(const std::string& certificateId, const std::string& recipientName, const std::string& eventName, std::tm issueDate, const std::string& position)
    : Certificate(certificateId, recipientName, eventName, issueDate), position(position) {}

std::string WinnerCertificate::getCertificateText() const {
    return "Congratulations! " + getRecipientName() + " secured " + position + " in " + getEventName() + " held on " + std::to_string(issueDate.tm_mday) + "/" + std::to_string(issueDate.tm_mon+1) + "/" + std::to_string(issueDate.tm_year+1900) + ".";
}

std::string WinnerCertificate::getPosition() const {
    return position;
}
