#include "Certificate.h"

Certificate::Certificate(const std::string& certificateId, const std::string& recipientName, const std::string& eventName, std::tm issueDate)
    : certificateId(certificateId), recipientName(recipientName), eventName(eventName), issueDate(issueDate) {}

std::string Certificate::getCertificateId() const { return certificateId; }
std::string Certificate::getRecipientName() const { return recipientName; }
std::string Certificate::getEventName() const { return eventName; }
std::tm Certificate::getIssueDate() const { return issueDate; }
