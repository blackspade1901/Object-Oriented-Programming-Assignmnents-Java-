#pragma once
#include "Certificate.h"
#include <string>

class WinnerCertificate : public Certificate {
public:
    WinnerCertificate(const std::string& certificateId, const std::string& recipientName, const std::string& eventName, std::tm issueDate, const std::string& position);
    std::string getCertificateText() const override;
    std::string getPosition() const;
private:
    std::string position;
};
