#pragma once
#include <string>
#include <vector>
#include "Sponsor.h"
#include "Event.h"
#include "Participant.h"
#include "Team.h"
#include "Certificate.h"
#include "Ledger.h"

class InfoFest {
public:
    InfoFest(const std::string& festName);
    void addSponsor(Sponsor* s);
    void addEvent(Event* e);
    void addParticipant(Participant* p);
    void addTeam(Team* t);
    void addCertificate(Certificate* c);
    void addFinanceRecord(const FinanceRecord& r);
    bool registerParticipant(const std::string& participantId, const std::string& eventName);
    Participant* findParticipant(const std::string& id);
    Event* findEvent(const std::string& name);
    double getNetBalance() const;
    void printSummary() const;
private:
    std::string festName;
    std::vector<Sponsor*> sponsors;
    std::vector<Event*> events;
    std::vector<Participant*> participants;
    std::vector<Team*> teams;
    std::vector<Certificate*> certificates;
    Ledger ledger;
};
