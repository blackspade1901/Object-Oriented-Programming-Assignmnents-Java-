#include "TechEvent.h"

TechEvent::TechEvent(const std::string& name, Mode mode, std::tm date, double entryFee, int teamLimit, const std::string& techStack, const std::string& tools)
    : Event(name, Type::TECH, mode, date, entryFee, teamLimit), techStack(techStack), tools(tools) {}

std::string TechEvent::getRules() const {
    return "Code must be original; internet reference allowed; plagiarism = disqualify.";
}

std::string TechEvent::getJudgingCriteria() const {
    return "Functionality 40%, Code Quality 30%, Innovation 30%.";
}

std::string TechEvent::getEventDetails() const {
    return getName() + " — " + techStack + " (" + (getEventMode() == Mode::OFFLINE ? "OFFLINE" : getEventMode() == Mode::ONLINE ? "ONLINE" : "HYBRID") + ")";
}

std::string TechEvent::getTechStack() const {
    return techStack;
}

std::string TechEvent::getTools() const {
    return tools;
}
