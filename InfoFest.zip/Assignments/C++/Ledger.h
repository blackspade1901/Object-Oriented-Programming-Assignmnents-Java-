#pragma once
#include <vector>
#include "FinanceRecord.h"

class Ledger {
public:
    void add(const FinanceRecord& r);
    double getBalance() const;
    std::vector<FinanceRecord> all() const;
private:
    std::vector<FinanceRecord> records;
};
