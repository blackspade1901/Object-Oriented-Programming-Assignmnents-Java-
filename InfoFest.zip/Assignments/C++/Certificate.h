#pragma once
#include <string>
#include <ctime>

class Certificate {
public:
    Certificate(const std::string& certificateId, const std::string& recipientName, const std::string& eventName, std::tm issueDate);
    virtual ~Certificate() = default;
    virtual std::string getCertificateText() const = 0;
    std::string getCertificateId() const;
    std::string getRecipientName() const;
    std::string getEventName() const;
    std::tm getIssueDate() const;
protected:
    std::string certificateId;
    std::string recipientName;
    std::string eventName;
    std::tm issueDate;
};
