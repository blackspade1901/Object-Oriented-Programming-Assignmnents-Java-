#include "ArtEvent.h"

ArtEvent::ArtEvent(const std::string& name, Mode mode, std::tm date, double entryFee, int teamLimit, Medium medium)
    : Event(name, Type::ART, mode, date, entryFee, teamLimit), medium(medium) {}

std::string ArtEvent::getRules() const {
    return "Artwork must be created on-site; topic revealed at start.";
}

std::string ArtEvent::getJudgingCriteria() const {
    return "Technique 40%, Originality 40%, Theme Fit 20%.";
}

std::string ArtEvent::getEventDetails() const {
    return getName() + " — " + (medium == Medium::DIGITAL ? "DIGITAL" : "TRADITIONAL") + " art";
}

ArtEvent::Medium ArtEvent::getMedium() const {
    return medium;
}
