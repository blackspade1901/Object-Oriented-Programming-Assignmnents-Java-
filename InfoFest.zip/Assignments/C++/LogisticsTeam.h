#pragma once
#include "Team.h"
#include <string>

class LogisticsTeam : public Team {
public:
    LogisticsTeam(const std::string& teamName, const std::string& lead);
    std::string getPrimaryTask() const override;
    std::string getDailyTools() const override;
    std::string getTeamDetails() const override;
};
