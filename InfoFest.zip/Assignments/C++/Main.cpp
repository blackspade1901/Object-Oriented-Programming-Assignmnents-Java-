#include "InfoFest.h"
#include "LocalSponsor.h"
#include "CorporateSponsor.h"
#include "TechEvent.h"
#include "NonTechEvent.h"
#include "ArtEvent.h"
#include "Participant.h"
#include "PromotionTeam.h"
#include "TechTeam.h"
#include "ParticipationCertificate.h"
#include "WinnerCertificate.h"
#include "FinanceRecord.h"
#include "FinanceType.h"
#include <ctime>

int main() {
    InfoFest fest("InfoFest-Lite 2025");

    LocalSponsor* local = new LocalSponsor(
        "Ravi Desai", 8000,
        "GoaPrints", "Stage banners",
        "Panaji", true);
    CorporateSponsor* corp = new CorporateSponsor(
        "Priya Shah", 75000,
        "CloudNova Ltd.", "Cash",
        "Software", true);
    fest.addSponsor(local);
    fest.addSponsor(corp);

    std::tm date1 = {};
    date1.tm_year = 2025 - 1900; date1.tm_mon = 0; date1.tm_mday = 24;
    TechEvent* hackathon = new TechEvent(
        "CodeCraft Marathon", Event::Mode::OFFLINE,
        date1, 200, 4,
        "Java / Spring", "IntelliJ");

    std::tm date2 = {};
    date2.tm_year = 2025 - 1900; date2.tm_mon = 0; date2.tm_mday = 24;
    NonTechEvent* memeRush = new NonTechEvent(
        "Meme-Forge Battle", Event::Mode::ONLINE,
        date2, 0, 1, "Pop-Culture");

    std::tm date3 = {};
    date3.tm_year = 2025 - 1900; date3.tm_mon = 0; date3.tm_mday = 25;
    ArtEvent* artShow = new ArtEvent(
        "Pixel-Palette Showdown", Event::Mode::HYBRID,
        date3, 100, 1, ArtEvent::Medium::DIGITAL);

    fest.addEvent(hackathon);
    fest.addEvent(memeRush);
    fest.addEvent(artShow);

    Participant* alice = new Participant("P-001", "Alice N.", "alice@mail.in", "Goa Univ");
    Participant* bob = new Participant("P-002", "Team ByteForce", "byte@uni.in", "Goa Univ");
    fest.addParticipant(alice);
    fest.addParticipant(bob);
    fest.registerParticipant("P-001", "Meme-Forge Battle");
    fest.registerParticipant("P-002", "CodeCraft Marathon");

    PromotionTeam* promo = new PromotionTeam("HypeSquad", "Riya Patel");
    promo->addMember("Sam");
    promo->addMember("Dee");
    fest.addTeam(promo);
    TechTeam* tech = new TechTeam("ByteCrew", "Akhil Rao");
    tech->addMember("Lila");
    fest.addTeam(tech);

    std::tm certDate1 = {};
    certDate1.tm_year = 2025 - 1900; certDate1.tm_mon = 0; certDate1.tm_mday = 25;
    ParticipationCertificate* c1 = new ParticipationCertificate(
        "C-101", "Alice N.", "Meme-Forge Battle", certDate1);
    std::tm certDate2 = {};
    certDate2.tm_year = 2025 - 1900; certDate2.tm_mon = 0; certDate2.tm_mday = 26;
    WinnerCertificate* c2 = new WinnerCertificate(
        "C-102", "Team ByteForce", "CodeCraft Marathon", certDate2, "First Place");
    fest.addCertificate(c1);
    fest.addCertificate(c2);

    std::tm finDate1 = {};
    finDate1.tm_year = 2025 - 1900; finDate1.tm_mon = 0; finDate1.tm_mday = 10;
    fest.addFinanceRecord(FinanceRecord(
        "F-001", finDate1, "CloudNova Sponsorship", 75000, FinanceType::INCOME));
    std::tm finDate2 = {};
    finDate2.tm_year = 2025 - 1900; finDate2.tm_mon = 0; finDate2.tm_mday = 15;
    fest.addFinanceRecord(FinanceRecord(
        "F-002", finDate2, "Poster Printing", 4500, FinanceType::EXPENSE));

    fest.printSummary();

    delete local;
    delete corp;
    delete hackathon;
    delete memeRush;
    delete artShow;
    delete alice;
    delete bob;
    delete promo;
    delete tech;
    delete c1;
    delete c2;
    return 0;
}
