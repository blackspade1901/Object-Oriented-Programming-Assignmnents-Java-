#pragma once
#include "Team.h"
#include <string>

class EventTeam : public Team {
public:
    EventTeam(const std::string& teamName, const std::string& lead);
    std::string getPrimaryTask() const override;
    std::string getDailyTools() const override;
    std::string getTeamDetails() const override;
};
