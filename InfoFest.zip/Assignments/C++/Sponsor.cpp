#include "Sponsor.h"

Sponsor::Sponsor(const std::string& name, double amount, const std::string& companyName, const std::string& itemName)
    : name(name), amount(amount), companyName(companyName), itemName(itemName), status(SponsorshipStatus::PENDING) {}

std::string Sponsor::getName() const { return name; }
double Sponsor::getAmount() const { return amount; }
std::string Sponsor::getCompanyName() const { return companyName; }
std::string Sponsor::getItemName() const { return itemName; }
Sponsor::SponsorshipStatus Sponsor::getStatus() const { return status; }
void Sponsor::setName(const std::string& n) { name = n; }
void Sponsor::setAmount(double a) { amount = a; }
void Sponsor::setCompanyName(const std::string& c) { companyName = c; }
void Sponsor::setItemName(const std::string& i) { itemName = i; }
void Sponsor::evaluateStatus() {
    const double approval_threshold = 10000.0;
    status = amount >= approval_threshold ? SponsorshipStatus::APPROVED : SponsorshipStatus::REJECTED;
}
