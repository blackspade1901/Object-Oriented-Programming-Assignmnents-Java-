#pragma once
#include <string>
#include <ctime>

class Event {
public:
    enum class Type { TECH, NON_TECH, ART };
    enum class Mode { OFFLINE, ONLINE, HYBRID };

    Event(const std::string& name, Type eventType, Mode eventMode, std::tm date, double entryFee, int teamLimit);
    virtual ~Event() = default;

    virtual std::string getRules() const = 0;
    virtual std::string getJudgingCriteria() const = 0;
    virtual std::string getEventDetails() const = 0;

    std::string getName() const;
    Type getEventType() const;
    Mode getEventMode() const;
    std::tm getDate() const;
    double getEntryFee() const;
    int getTeamLimit() const;
protected:
    std::string name;
    Type eventType;
    Mode eventMode;
    std::tm date;
    double entryFee;
    int teamLimit;
};
