#pragma once
#include "Event.h"
#include <string>

class ArtEvent : public Event {
public:
    enum class Medium { DIGITAL, TRADITIONAL };
    ArtEvent(const std::string& name, Mode mode, std::tm date, double entryFee, int teamLimit, Medium medium);
    std::string getRules() const override;
    std::string getJudgingCriteria() const override;
    std::string getEventDetails() const override;
    Medium getMedium() const;
private:
    Medium medium;
};
