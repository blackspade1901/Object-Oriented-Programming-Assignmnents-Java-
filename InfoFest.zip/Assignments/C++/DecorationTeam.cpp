#include "DecorationTeam.h"

DecorationTeam::DecorationTeam(const std::string& teamName, const std::string& lead)
    : Team(teamName, lead) {}

std::string DecorationTeam::getPrimaryTask() const {
    return "Design & install venue décor";
}

std::string DecorationTeam::getDailyTools() const {
    return "Sketches, colours, Painting Brushes, Cloths, toolkits, Lights";
}

std::string DecorationTeam::getTeamDetails() const {
    return getTeamName() + " crafts the visual theme and ambience.";
}
