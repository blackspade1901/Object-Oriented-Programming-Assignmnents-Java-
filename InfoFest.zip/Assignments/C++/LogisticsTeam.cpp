#include "LogisticsTeam.h"

LogisticsTeam::LogisticsTeam(const std::string& teamName, const std::string& lead)
    : Team(teamName, lead) {}

std::string LogisticsTeam::getPrimaryTask() const {
    return "Venue, transport, hospitality coordination";
}

std::string LogisticsTeam::getDailyTools() const {
    return "Trello board, vendor contacts, maps";
}

std::string LogisticsTeam::getTeamDetails() const {
    return getTeamName() + " books halls, buses, food, and handles guest arrivals.";
}
