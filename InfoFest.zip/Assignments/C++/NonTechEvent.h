#pragma once
#include "Event.h"
#include <string>

class NonTechEvent : public Event {
public:
    NonTechEvent(const std::string& name, Mode mode, std::tm date, double entryFee, int teamLimit, const std::string& theme);
    std::string getRules() const override;
    std::string getJudgingCriteria() const override;
    std::string getEventDetails() const override;
    std::string getTheme() const;
private:
    std::string theme;
};
