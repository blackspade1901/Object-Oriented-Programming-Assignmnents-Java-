#pragma once
#include "Sponsor.h"
#include <string>

class LocalSponsor : public Sponsor {
public:
    LocalSponsor(const std::string& name, double amount, const std::string& companyName, const std::string& itemName, const std::string& locality, bool recurring);
    double calculateSponsorshipValue() const override;
    std::string getSponsorshipTier() const override;
    std::string getSponsorDetails() const override;
    std::string getLocality() const;
    bool isRecurring() const;
private:
    std::string locality;
    bool recurring;
};
