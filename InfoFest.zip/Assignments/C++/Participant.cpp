#include "Participant.h"

Participant::Participant(const std::string& participantId, const std::string& name, const std::string& email, const std::string& college)
    : participantId(participantId), name(name), email(email), college(college) {}

bool Participant::registerEvent(Event* event) {
    for (auto* e : registeredEvents) {
        if (e == event) return false;
    }
    registeredEvents.push_back(event);
    return true;
}

bool Participant::cancelEvent(Event* event) {
    for (auto it = registeredEvents.begin(); it != registeredEvents.end(); ++it) {
        if (*it == event) {
            registeredEvents.erase(it);
            return true;
        }
    }
    return false;
}

std::vector<Event*> Participant::getRegisteredEvents() const {
    return registeredEvents;
}

std::string Participant::getParticipantId() const { return participantId; }
std::string Participant::getName() const { return name; }
std::string Participant::getEmail() const { return email; }
std::string Participant::getCollege() const { return college; }
void Participant::setName(const std::string& n) { name = n; }
void Participant::setEmail(const std::string& e) { email = e; }
void Participant::setCollege(const std::string& c) { college = c; }
