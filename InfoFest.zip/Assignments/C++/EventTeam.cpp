#include "EventTeam.h"

EventTeam::EventTeam(const std::string& teamName, const std::string& lead)
    : Team(teamName, lead) {}

std::string EventTeam::getPrimaryTask() const {
    return "Run stage-time, schedules, and on-site flow";
}

std::string EventTeam::getDailyTools() const {
    return "G-Sheets schedule, radios, walkie-apps";
}

std::string EventTeam::getTeamDetails() const {
    return getTeamName() + " led by " + getTeamLead() + " handles all live-event execution.";
}
