public class DecorationTeam : Team
{
	public DecorationTeam(string teamName, string lead)
		: base(teamName, lead)
	{
	}

	public override string GetPrimaryTask()
	{
		return "Design & install venue décor";
	}

	public override string GetDailyTools()
	{
		return "Sketches, colours, Painting Brushes, Cloths, toolkits, Lights";
	}

	public override string GetTeamDetails()
	{
		return GetTeamName() + " crafts the visual theme and ambience.";
	}
}
