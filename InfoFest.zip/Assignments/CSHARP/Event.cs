using System;

public abstract class Event
{
	private string name;
	private Type eventType;
	private Mode eventMode;
	private DateTime date;
	private double entryFee;
	private int teamLimit;

	public enum Type { TECH, NON_TECH, ART }
	public enum Mode { OFFLINE, ONLINE, HYBRID }

	public Event(string name, Type eventType, Mode eventMode, DateTime date, double entryFee, int teamLimit)
	{
		this.name = name;
		this.eventType = eventType;
		this.eventMode = eventMode;
		this.date = date;
		this.entryFee = entryFee;
		this.teamLimit = teamLimit;
	}

	public abstract string GetRules();
	public abstract string GetJudgingCriteria();
	public abstract string GetEventDetails();

	public string GetName() { return name; }
	public Type GetEventType() { return eventType; }
	public Mode GetEventMode() { return eventMode; }
	public DateTime GetDate() { return date; }
	public double GetEntryFee() { return entryFee; }
	public int GetTeamLimit() { return teamLimit; }
}
