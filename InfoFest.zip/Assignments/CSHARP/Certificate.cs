using System;

public abstract class Certificate
{
	private readonly string certificateId;
	private readonly string recipientName;
	private readonly string eventName;
	private readonly DateTime issueDate;

	public Certificate(string certificateId, string recipientName, string eventName, DateTime issueDate)
	{
		this.certificateId = certificateId;
		this.recipientName = recipientName;
		this.eventName = eventName;
		this.issueDate = issueDate;
	}

	public abstract string GetCertificateText();

	public string GetCertificateId() { return certificateId; }
	public string GetRecipientName() { return recipientName; }
	public string GetEventName() { return eventName; }
	public DateTime GetIssueDate() { return issueDate; }
}
