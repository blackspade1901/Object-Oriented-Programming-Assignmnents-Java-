public class CorporateSponsor : Sponsor
{
	private string industry;
	private bool nationalBrand;

	public CorporateSponsor(string name, double amount, string companyName, string itemName, string industry, bool nationalBrand)
		: base(name, amount, companyName, itemName)
	{
		this.industry = industry;
		this.nationalBrand = nationalBrand;
	}

	public override double CalculateSponsorshipValue()
	{
		return nationalBrand ? amount * 1.20 : amount;
	}

	public override string GetSponsorshipTier()
	{
		return amount >= 25000 ? "Corporate-Platinum"
			 : amount >= 20000 ? "Corporate-Gold"
			 : amount >= 15000 ? "Corporate-Silver"
			 : "Corporate-Bronze";
	}

	public override string GetSponsorDetails()
	{
		return companyName + " — " + industry + " sector";
	}

	public string GetIndustry() { return industry; }
	public bool IsNationalBrand() { return nationalBrand; }
}
