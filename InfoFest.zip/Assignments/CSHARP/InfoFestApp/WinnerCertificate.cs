using System;

public class WinnerCertificate : Certificate
{
	private readonly string position;

	public WinnerCertificate(string certificateId, string recipientName, string eventName, DateTime issueDate, string position)
		: base(certificateId, recipientName, eventName, issueDate)
	{
		this.position = position;
	}

	public override string GetCertificateText()
	{
		return $"Congratulations! {GetRecipientName()} secured {position} in {GetEventName()} held on {GetIssueDate():yyyy-MM-dd}.";
	}

	public string GetPosition() { return position; }
}
