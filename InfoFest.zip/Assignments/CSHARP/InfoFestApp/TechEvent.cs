using System;

public class TechEvent : Event
{
	private string techStack;
	private string tools;

	public TechEvent(string name, Mode mode, DateTime date, double entryFee, int teamLimit, string techStack, string tools)
		: base(name, Type.TECH, mode, date, entryFee, teamLimit)
	{
		this.techStack = techStack;
		this.tools = tools;
	}

	public override string GetRules()
	{
		return "Code must be original; internet reference allowed; plagiarism = disqualify.";
	}

	public override string GetJudgingCriteria()
	{
		return "Functionality 40%, Code Quality 30%, Innovation 30%.";
	}

	public override string GetEventDetails()
	{
		return GetName() + " — " + techStack + " (" + GetEventMode() + ")";
	}

	public string GetTechStack() { return techStack; }
	public string GetTools() { return tools; }
}
