using System.Collections.Generic;

public abstract class Team
{
	private string teamName;
	private string teamLead;
	private readonly List<string> members = new List<string>();

	public Team(string teamName, string teamLead)
	{
		this.teamName = teamName;
		this.teamLead = teamLead;
	}

	public abstract string GetPrimaryTask();
	public abstract string GetDailyTools();
	public abstract string GetTeamDetails();

	public void AddMember(string member) { members.Add(member); }
	public List<string> GetMembers() { return new List<string>(members); }

	public string GetTeamName() { return teamName; }
	public string GetTeamLead() { return teamLead; }
	public void SetTeamLead(string lead) { this.teamLead = lead; }
}
