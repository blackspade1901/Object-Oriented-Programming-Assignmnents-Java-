public class LogisticsTeam : Team
{
	public LogisticsTeam(string teamName, string lead)
		: base(teamName, lead)
	{
	}

	public override string GetPrimaryTask()
	{
		return "Venue, transport, hospitality coordination";
	}

	public override string GetDailyTools()
	{
		return "Trello board, vendor contacts, maps";
	}

	public override string GetTeamDetails()
	{
		return GetTeamName() + " books halls, buses, food, and handles guest arrivals.";
	}
}
