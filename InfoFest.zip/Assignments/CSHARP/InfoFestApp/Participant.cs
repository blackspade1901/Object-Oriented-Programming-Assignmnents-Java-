using System.Collections.Generic;

public class Participant
{
	private readonly string participantId;
	private string name;
	private string email;
	private string college;
	private readonly List<Event> registeredEvents = new List<Event>();

	public Participant(string participantId, string name, string email, string college)
	{
		this.participantId = participantId;
		this.name = name;
		this.email = email;
		this.college = college;
	}

	public bool Register(Event ev)
	{
		if (registeredEvents.Contains(ev)) return false;
		registeredEvents.Add(ev);
		return true;
	}

	public bool Cancel(Event ev)
	{
		return registeredEvents.Remove(ev);
	}

	public List<Event> GetRegisteredEvents()
	{
		return new List<Event>(registeredEvents);
	}

	public string GetParticipantId() { return participantId; }
	public string GetName() { return name; }
	public string GetEmail() { return email; }
	public string GetCollege() { return college; }

	public void SetName(string name) { this.name = name; }
	public void SetEmail(string email) { this.email = email; }
	public void SetCollege(string college) { this.college = college; }
}
