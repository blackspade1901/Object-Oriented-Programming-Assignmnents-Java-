public abstract class Sponsor
{
	protected string name;
	protected double amount;
	protected string companyName;
	protected string itemName;
	private SponsorshipStatus status;

	public enum SponsorshipStatus
	{
		PENDING, APPROVED, ACTIVE, REJECTED
	}

	public Sponsor(string name, double amount, string companyName, string itemName)
	{
		this.name = name;
		this.amount = amount;
		this.companyName = companyName;
		this.itemName = itemName;
		this.status = SponsorshipStatus.PENDING;
	}

	public abstract double CalculateSponsorshipValue();
	public abstract string GetSponsorshipTier();
	public abstract string GetSponsorDetails();

	public string GetName() { return name; }
	public double GetAmount() { return amount; }
	public string GetCompanyName() { return companyName; }
	public string GetItemName() { return itemName; }
	public SponsorshipStatus GetStatus() { return status; }

	public void SetName(string name) { this.name = name; }
	public void SetAmount(double amount) { this.amount = amount; }
	public void SetCompanyName(string companyName) { this.companyName = companyName; }
	public void SetItemName(string itemName) { this.itemName = itemName; }

	public void EvaluateStatus()
	{
		const double approval_threshold = 10000.0;
		this.status = amount >= approval_threshold ? SponsorshipStatus.APPROVED : SponsorshipStatus.REJECTED;
	}
}
