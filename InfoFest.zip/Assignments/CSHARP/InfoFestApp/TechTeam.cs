public class TechTeam : Team
{
	public TechTeam(string teamName, string lead)
		: base(teamName, lead)
	{
	}

	public override string GetPrimaryTask()
	{
		return "Website, registration portal, live-stream";
	}

	public override string GetDailyTools()
	{
		return "VS Code, GitHub, OBS, cloud console";
	}

	public override string GetTeamDetails()
	{
		return GetTeamName() + " maintains the site, Wi-Fi, and social-media integrations.";
	}
}
