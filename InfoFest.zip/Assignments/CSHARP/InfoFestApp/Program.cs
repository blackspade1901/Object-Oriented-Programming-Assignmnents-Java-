﻿// Entry point for InfoFestApp
MainClass.Main(new string[0]);
