public class LocalSponsor : Sponsor
{
	private string locality;
	private bool recurring;

	public LocalSponsor(string name, double amount, string companyName, string itemName, string locality, bool recurring)
		: base(name, amount, companyName, itemName)
	{
		this.locality = locality;
		this.recurring = recurring;
	}

	public override double CalculateSponsorshipValue()
	{
		return recurring ? amount * 1.10 : amount;
	}

	public override string GetSponsorshipTier()
	{
		return amount >= 10000 ? "Local-Premium"
			 : amount >= 5000 ? "Local-Standard"
			 : "Local-Supporter";
	}

	public override string GetSponsorDetails()
	{
		return companyName + " (\"" + locality + "\")";
	}

	public string GetLocality() { return locality; }
	public bool IsRecurring() { return recurring; }
}
