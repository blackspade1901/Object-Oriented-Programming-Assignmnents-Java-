using System.Collections.Generic;

public class Ledger
{
	private readonly List<FinanceRecord> records = new List<FinanceRecord>();

	public void Add(FinanceRecord r) { records.Add(r); }

	public double GetBalance()
	{
		double total = 0.0;
		foreach (FinanceRecord r in records)
		{
			total += r.SignedAmount();
		}
		return total;
	}

	public List<FinanceRecord> All()
	{
		return new List<FinanceRecord>(records);
	}
}
