public class PromotionTeam : Team
{
	public PromotionTeam(string teamName, string lead)
		: base(teamName, lead)
	{
	}

	public override string GetPrimaryTask()
	{
		return "Market the fest and grow audience reach";
	}

	public override string GetDailyTools()
	{
		return "Instagram, LinkedIn, Canva, Buffer";
	}

	public override string GetTeamDetails()
	{
		return GetTeamName() + " curates social posts, posters, and press releases.";
	}
}
