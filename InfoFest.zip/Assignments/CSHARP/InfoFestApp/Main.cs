using System;

public class MainClass
{
	public static void Main(string[] args)
	{
		InfoFest fest = new InfoFest("InfoFest-Lite 2025");

		Sponsor local = new LocalSponsor(
			"Ravi Desai", 8000,
			"GoaPrints", "Stage banners",
			"Panaji", true);
		Sponsor corp = new CorporateSponsor(
			"Priya Shah", 75000,
			"CloudNova Ltd.", "Cash",
			"Software", true);

		fest.AddSponsor(local);
		fest.AddSponsor(corp);

		Event hackathon = new TechEvent(
			"CodeCraft Marathon", Event.Mode.OFFLINE,
			new DateTime(2025, 1, 24),
			200, 4,
			"Java / Spring", "IntelliJ");

		Event memeRush = new NonTechEvent(
			"Meme-Forge Battle", Event.Mode.ONLINE,
			new DateTime(2025, 1, 24),
			0, 1, "Pop-Culture");

		Event artShow = new ArtEvent(
			"Pixel-Palette Showdown", Event.Mode.HYBRID,
			new DateTime(2025, 1, 25),
			100, 1, ArtEvent.Medium.DIGITAL);

		fest.AddEvent(hackathon);
		fest.AddEvent(memeRush);
		fest.AddEvent(artShow);

		Participant alice = new Participant("P-001", "Alice N.", "alice@mail.in", "Goa Univ");
		Participant bob = new Participant("P-002", "Team ByteForce", "byte@uni.in", "Goa Univ");

		fest.AddParticipant(alice);
		fest.AddParticipant(bob);

		fest.Register("P-001", "Meme-Forge Battle");
		fest.Register("P-002", "CodeCraft Marathon");

		Team promo = new PromotionTeam("HypeSquad", "Riya Patel");
		promo.AddMember("Sam");
		promo.AddMember("Dee");
		fest.AddTeam(promo);

		Team tech = new TechTeam("ByteCrew", "Akhil Rao");
		tech.AddMember("Lila");
		fest.AddTeam(tech);

		Certificate c1 = new ParticipationCertificate(
			"C-101", "Alice N.", "Meme-Forge Battle",
			new DateTime(2025, 1, 25));
		Certificate c2 = new WinnerCertificate(
			"C-102", "Team ByteForce", "CodeCraft Marathon",
			new DateTime(2025, 1, 26), "First Place");

		fest.AddCertificate(c1);
		fest.AddCertificate(c2);

		fest.AddFinanceRecord(new FinanceRecord(
			"F-001", new DateTime(2025, 1, 10),
			"CloudNova Sponsorship", 75000, FinanceType.INCOME));
		fest.AddFinanceRecord(new FinanceRecord(
			"F-002", new DateTime(2025, 1, 15),
			"Poster Printing", 4500, FinanceType.EXPENSE));

		fest.PrintSummary();
	}
}
