using System;

public class ParticipationCertificate : Certificate
{
	public ParticipationCertificate(string certificateId, string recipientName, string eventName, DateTime issueDate)
		: base(certificateId, recipientName, eventName, issueDate)
	{
	}

	public override string GetCertificateText()
	{
		return $"This is to certify that {GetRecipientName()} participated in {GetEventName()} on {GetIssueDate():yyyy-MM-dd}.";
	}
}
