using System;

public class NonTechEvent : Event
{
	private string theme;

	public NonTechEvent(string name, Mode mode, DateTime date, double entryFee, int teamLimit, string theme)
		: base(name, Type.NON_TECH, mode, date, entryFee, teamLimit)
	{
		this.theme = theme;
	}

	public override string GetRules()
	{
		return "Original content only; no profanity; time limit 2 hours.";
	}

	public override string GetJudgingCriteria()
	{
		return "Creativity 50%, Audience Impact 30%, Theme Relevance 20%.";
	}

	public override string GetEventDetails()
	{
		return GetName() + " — theme: " + theme;
	}

	public string GetTheme() { return theme; }
}
