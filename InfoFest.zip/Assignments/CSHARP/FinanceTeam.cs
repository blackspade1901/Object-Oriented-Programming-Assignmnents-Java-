public class FinanceTeam : Team
{
	public FinanceTeam(string teamName, string lead)
		: base(teamName, lead)
	{
	}

	public override string GetPrimaryTask()
	{
		return "Budget tracking and payment clearance";
	}

	public override string GetDailyTools()
	{
		return "Excel, UPI dashboard, receipt scanner";
	}

	public override string GetTeamDetails()
	{
		return GetTeamName() + " records income/expenses and settles vendor invoices.";
	}
}
