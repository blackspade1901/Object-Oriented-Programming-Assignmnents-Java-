using System;
using System.Collections.Generic;

public class InfoFest
{
	private readonly string festName;

	private readonly List<Sponsor> sponsors = new List<Sponsor>();
	private readonly List<Event> events = new List<Event>();
	private readonly List<Participant> participants = new List<Participant>();
	private readonly List<Team> teams = new List<Team>();
	private readonly List<Certificate> certificates = new List<Certificate>();

	private readonly Ledger ledger = new Ledger();

	public InfoFest(string festName)
	{
		this.festName = festName;
	}

	public void AddSponsor(Sponsor s) { sponsors.Add(s); }
	public void AddEvent(Event e) { events.Add(e); }
	public void AddParticipant(Participant p) { participants.Add(p); }
	public void AddTeam(Team t) { teams.Add(t); }
	public void AddCertificate(Certificate c) { certificates.Add(c); }
	public void AddFinanceRecord(FinanceRecord r) { ledger.Add(r); }

	public bool Register(string participantId, string eventName)
	{
		Participant p = FindParticipant(participantId);
		Event e = FindEvent(eventName);
		if (p == null || e == null) return false;
		return p.Register(e);
	}

	public Participant FindParticipant(string id)
	{
		foreach (Participant p in participants)
		{
			if (p.GetParticipantId() == id) return p;
		}
		return null;
	}
	public Event FindEvent(string name)
	{
		foreach (Event e in events)
		{
			if (e.GetName().Equals(name, StringComparison.OrdinalIgnoreCase)) return e;
		}
		return null;
	}

	public double GetNetBalance() { return ledger.GetBalance(); }

	public void PrintSummary()
	{
		Console.WriteLine($"=== {festName} SUMMARY ===");

		Console.WriteLine($"\nSponsors ({sponsors.Count}):");
		foreach (Sponsor s in sponsors)
		{
			Console.WriteLine($" - {s.GetSponsorDetails()}");
		}

		Console.WriteLine($"\nEvents ({events.Count}):");
		foreach (Event e in events)
		{
			Console.WriteLine($" - {e.GetEventDetails()}");
		}

		Console.WriteLine($"\nParticipants ({participants.Count}):");
		foreach (Participant p in participants)
		{
			Console.WriteLine($" - {p.GetName()} -> {p.GetRegisteredEvents().Count} events");
		}

		Console.WriteLine($"\nTeams ({teams.Count}):");
		foreach (Team t in teams)
		{
			Console.WriteLine($" - {t.GetTeamName()} ({t.GetMembers().Count} members)");
		}

		Console.WriteLine($"\nCertificates ({certificates.Count}):");
		foreach (Certificate c in certificates)
		{
			Console.WriteLine($" - {c.GetCertificateText()}");
		}

		Console.WriteLine($"\nFinance balance: ₹{GetNetBalance()}");
		Console.WriteLine($"==================================");
	}
}
