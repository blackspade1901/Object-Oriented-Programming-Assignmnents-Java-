public class EventTeam : Team
{
	public EventTeam(string teamName, string lead)
		: base(teamName, lead)
	{
	}

	public override string GetPrimaryTask()
	{
		return "Run stage-time, schedules, and on-site flow";
	}

	public override string GetDailyTools()
	{
		return "G-Sheets schedule, radios, walkie-apps";
	}

	public override string GetTeamDetails()
	{
		return GetTeamName() + " led by " + GetTeamLead() + " handles all live-event execution.";
	}
}
