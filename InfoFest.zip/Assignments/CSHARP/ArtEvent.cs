using System;
using System.Globalization;
using System;
using System.Collections.Generic;

public class ArtEvent : Event
{
	public enum Medium { DIGITAL, TRADITIONAL }
	private Medium medium;

	public ArtEvent(string name, Mode mode, DateTime date, double entryFee, int teamLimit, Medium medium)
		: base(name, Type.ART, mode, date, entryFee, teamLimit)
	{
		this.medium = medium;
	}

	public override string GetRules()
	{
		return "Artwork must be created on-site; topic revealed at start.";
	}

	public override string GetJudgingCriteria()
	{
		return "Technique 40%, Originality 40%, Theme Fit 20%.";
	}

	public override string GetEventDetails()
	{
		return GetName() + " — " + medium + " art";
	}

	public Medium GetMedium() { return medium; }
}
