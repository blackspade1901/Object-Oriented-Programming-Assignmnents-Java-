using System;

public sealed class FinanceRecord
{
	private readonly string id;
	private readonly DateTime date;
	private readonly string description;
	private readonly double amount;
	private readonly FinanceType type;

	public FinanceRecord(string id, DateTime date, string description, double amount, FinanceType type)
	{
		this.id = id;
		this.date = date;
		this.description = description;
		this.amount = amount;
		this.type = type;
	}

	public string GetId() { return id; }
	public DateTime GetDate() { return date; }
	public string GetDescription() { return description; }
	public double GetAmount() { return amount; }
	public FinanceType GetType() { return type; }

	public double SignedAmount()
	{
		return type == FinanceType.INCOME ? amount : -amount;
	}
}
